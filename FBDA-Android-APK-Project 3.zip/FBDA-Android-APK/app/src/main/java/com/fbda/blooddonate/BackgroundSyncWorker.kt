package com.fbda.blooddonate

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class BackgroundSyncWorker(
    context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        return try {
            ForegroundKeepAliveService.syncLatestDataInBackground(applicationContext)
            OtaHtmlUpdater.checkAndDownloadIfNeeded(applicationContext)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
