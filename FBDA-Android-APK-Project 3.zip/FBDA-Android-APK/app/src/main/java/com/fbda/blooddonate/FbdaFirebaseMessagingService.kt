package com.fbda.blooddonate

import android.content.Context
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FbdaFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("fcm_token", token)
            .apply()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val title = remoteMessage.notification?.title
            ?: remoteMessage.data["title"]
            ?: getString(R.string.app_name)
        val body = remoteMessage.notification?.body
            ?: remoteMessage.data["body"]
            ?: remoteMessage.data["message"]
            ?: "New blood donation update."
        val deepLink = remoteMessage.data["url"]
            ?: remoteMessage.data["deep_link"]
            ?: "#home"
        val actionLabel = remoteMessage.data["action_label"]
        val phoneNumber = remoteMessage.data["phone"]
        val channelId = if (remoteMessage.data["type"] == "notice") {
            NotificationHelper.CHANNEL_NOTICES
        } else {
            NotificationHelper.CHANNEL_URGENT
        }

        NotificationHelper.showAlertNotification(
            context = this,
            title = title,
            body = body,
            deepLink = deepLink,
            actionLabel = actionLabel,
            phoneNumber = phoneNumber,
            channelId = channelId
        )
    }
}
