package com.fbda.blooddonate

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object OtaHtmlUpdater {
    private const val PREFS = "fbda_prefs"
    private const val KEY_OTA_MANIFEST_URL = "ota_manifest_url"
    private const val KEY_OTA_VERSION = "ota_html_version"

    fun getEntryUrl(context: Context): String {
        val otaFile = File(File(context.filesDir, "ota"), "index.html")
        return if (otaFile.exists() && otaFile.length() > 512) {
            "file://${otaFile.absolutePath}"
        } else {
            "file:///android_asset/index.html"
        }
    }

    fun getManifestUrl(context: Context): String {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_OTA_MANIFEST_URL, "") ?: ""
        if (saved.isNotBlank()) return saved
        return context.getString(R.string.ota_manifest_url).trim()
    }

    fun setManifestUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_OTA_MANIFEST_URL, url.trim())
            .apply()
    }

    fun getCurrentVersion(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_OTA_VERSION, "bundled-1.0.0") ?: "bundled-1.0.0"
    }

    fun resetToBundled(context: Context) {
        val otaFile = File(File(context.filesDir, "ota"), "index.html")
        if (otaFile.exists()) otaFile.delete()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_OTA_VERSION, "bundled-1.0.0")
            .apply()
    }

    /**
     * Checks remote OTA manifest JSON: { "version": "...", "htmlUrl": "..." }
     * Downloads updated HTML atomically into filesDir/ota/index.html if version changed.
     */
    fun checkAndDownloadIfNeeded(context: Context): Boolean {
        val manifestUrl = getManifestUrl(context)
        if (manifestUrl.isBlank() || !manifestUrl.startsWith("https://")) return false

        return try {
            val conn = (URL(manifestUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
            }
            if (conn.responseCode !in 200..299) {
                conn.disconnect()
                return false
            }
            val manifestText = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val json = JSONObject(manifestText)
            val remoteVersion = json.optString("version", "")
            var htmlUrl = json.optString("htmlUrl", "")
            if (remoteVersion.isBlank() || htmlUrl.isBlank()) return false

            if (remoteVersion == getCurrentVersion(context)) return false

            if (htmlUrl.startsWith("/")) {
                val base = URL(manifestUrl)
                htmlUrl = "${base.protocol}://${base.authority}$htmlUrl"
            }
            if (!htmlUrl.startsWith("https://")) return false

            val htmlConn = (URL(htmlUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 12000
            }
            if (htmlConn.responseCode !in 200..299) {
                htmlConn.disconnect()
                return false
            }
            val html = htmlConn.inputStream.bufferedReader().use { it.readText() }
            htmlConn.disconnect()

            if (!html.contains("<html", ignoreCase = true) || html.length < 512) {
                return false
            }

            val otaDir = File(context.filesDir, "ota").apply { mkdirs() }
            val tempFile = File(otaDir, "index.html.tmp")
            val targetFile = File(otaDir, "index.html")
            tempFile.writeText(html, Charsets.UTF_8)
            if (targetFile.exists()) targetFile.delete()
            tempFile.renameTo(targetFile)

            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_OTA_VERSION, remoteVersion)
                .apply()

            true
        } catch (_: Exception) {
            false
        }
    }
}
