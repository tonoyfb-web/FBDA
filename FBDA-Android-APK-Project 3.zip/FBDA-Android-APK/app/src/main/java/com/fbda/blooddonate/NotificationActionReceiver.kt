package com.fbda.blooddonate

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            ACTION_DISMISS -> {
                val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, -1)
                if (notifId != -1) {
                    NotificationManagerCompat.from(context).cancel(notifId)
                }
            }
            ACTION_STOP_AUDIO -> {
                ForegroundKeepAliveService.stopAudio(context)
            }
            ACTION_STOP_SERVICE -> {
                context.getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("bg_service_enabled", false)
                    .apply()
                ForegroundKeepAliveService.stop(context)
            }
        }
    }

    companion object {
        const val ACTION_DISMISS = "com.fbda.blooddonate.ACTION_DISMISS"
        const val ACTION_STOP_AUDIO = "com.fbda.blooddonate.ACTION_STOP_AUDIO"
        const val ACTION_STOP_SERVICE = "com.fbda.blooddonate.ACTION_STOP_SERVICE"
        const val EXTRA_NOTIF_ID = "notif_id"
    }
}
