package com.fbda.blooddonate

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                fetchAndDeliverFcmToken()
            }
        }

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            fileUploadCallback?.onReceiveValue(uris)
            fileUploadCallback = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        NotificationHelper.createChannels(this)

        webView = WebView(this)
        setContentView(webView)

        configureWebView(webView)
        applySystemFontScaleToWebView(resources.configuration.fontScale)

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.loadUrl(OtaHtmlUpdater.getEntryUrl(this))

        handleDeepLinkIntent(intent)
        ensureBackgroundMonitoringActive()
        requestNotificationPermissionIfNeeded()
        checkForOtaUpdateSilently()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: WebView) {
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    return true
                }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (!url.contains("supabase.co")) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        return true
                    }
                }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val fontScale = resources.configuration.fontScale
                view?.evaluateJavascript(
                    "window.onSystemFontScaleChanged && window.onSystemFontScaleChanged($fontScale);",
                    null
                )
                fetchAndDeliverFcmToken()
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: return false
                    fileChooserLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    fileUploadCallback = null
                    false
                }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applySystemFontScaleToWebView(newConfig.fontScale)
        webView.post {
            webView.evaluateJavascript(
                "window.onSystemFontScaleChanged && window.onSystemFontScaleChanged(${newConfig.fontScale});",
                null
            )
        }
    }

    private fun applySystemFontScaleToWebView(fontScale: Float) {
        val zoomPercent = (fontScale * 100f).toInt().coerceIn(85, 200)
        webView.settings.textZoom = zoomPercent
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLinkIntent(intent)
    }

    private fun handleDeepLinkIntent(intent: Intent?) {
        val deepLink = intent?.getStringExtra("deep_link") ?: return
        val safe = deepLink.replace("'", "")
        webView.postDelayed({
            webView.evaluateJavascript(
                "window.onPushDeepLink && window.onPushDeepLink('$safe');",
                null
            )
        }, 400)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                fetchAndDeliverFcmToken()
            }
        } else {
            fetchAndDeliverFcmToken()
        }
    }

    private fun fetchAndDeliverFcmToken() {
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
            if (FirebaseApp.getApps(this).isEmpty()) return
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                if (!token.isNullOrBlank()) {
                    getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("fcm_token", token)
                        .apply()
                    webView.post {
                        val safe = token.replace("'", "")
                        webView.evaluateJavascript(
                            "window.onFcmTokenReceived && window.onFcmTokenReceived('$safe');",
                            null
                        )
                    }
                }
            }
        } catch (_: Exception) {
            // Firebase not yet configured via google-services.json
        }
    }

    private fun checkForOtaUpdateSilently() {
        ioExecutor.execute {
            val updated = OtaHtmlUpdater.checkAndDownloadIfNeeded(this)
            if (updated) {
                runOnUiThread {
                    webView.loadUrl(OtaHtmlUpdater.getEntryUrl(this))
                }
            }
        }
    }

    private fun ensureBackgroundMonitoringActive() {
        val prefs = getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("bg_service_enabled", true)
        if (enabled) {
            ForegroundKeepAliveService.start(this)
            schedulePeriodicSyncWorker()
        }
    }

    private fun schedulePeriodicSyncWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<BackgroundSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "fbda_background_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    override fun onDestroy() {
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun getPlatform(): String = "android"

        @JavascriptInterface
        fun getSystemFontScale(): Float = resources.configuration.fontScale

        @JavascriptInterface
        fun getCachedFcmToken(): String {
            return getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                .getString("fcm_token", "") ?: ""
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            runOnUiThread { requestNotificationPermissionIfNeeded() }
        }

        @JavascriptInterface
        fun setBackgroundServiceEnabled(enabled: Boolean) {
            getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean("bg_service_enabled", enabled)
                .apply()

            if (enabled) {
                ForegroundKeepAliveService.start(this@MainActivity)
                schedulePeriodicSyncWorker()
            } else {
                ForegroundKeepAliveService.stop(this@MainActivity)
                WorkManager.getInstance(this@MainActivity).cancelUniqueWork("fbda_background_sync")
            }
        }

        @JavascriptInterface
        fun isBackgroundServiceEnabled(): Boolean {
            return getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                .getBoolean("bg_service_enabled", true)
        }

        @JavascriptInterface
        fun showLocalNotification(title: String, body: String, deepLink: String) {
            NotificationHelper.showAlertNotification(this@MainActivity, title, body, deepLink)
        }

        @JavascriptInterface
        fun playAlertTone() {
            ForegroundKeepAliveService.playTone(this@MainActivity)
        }

        @JavascriptInterface
        fun playBackgroundAudio(url: String) {
            if (url.startsWith("https://")) {
                ForegroundKeepAliveService.playAudioUrl(this@MainActivity, url)
            }
        }

        @JavascriptInterface
        fun stopBackgroundAudio() {
            ForegroundKeepAliveService.stopAudio(this@MainActivity)
        }

        @JavascriptInterface
        fun getCurrentHtmlVersion(): String = OtaHtmlUpdater.getCurrentVersion(this@MainActivity)

        @JavascriptInterface
        fun setOtaServerUrl(url: String) {
            OtaHtmlUpdater.setManifestUrl(this@MainActivity, url)
        }

        @JavascriptInterface
        fun checkForHtmlUpdate() {
            ioExecutor.execute {
                val updated = OtaHtmlUpdater.checkAndDownloadIfNeeded(this@MainActivity)
                runOnUiThread {
                    if (updated) {
                        webView.loadUrl(OtaHtmlUpdater.getEntryUrl(this@MainActivity))
                    } else {
                        webView.evaluateJavascript(
                            "window.showAlert && window.showAlert('App HTML is already up to date.', 'success');",
                            null
                        )
                    }
                }
            }
        }

        @JavascriptInterface
        fun resetToBundledHtml() {
            OtaHtmlUpdater.resetToBundled(this@MainActivity)
            runOnUiThread {
                webView.loadUrl(OtaHtmlUpdater.getEntryUrl(this@MainActivity))
            }
        }

        @JavascriptInterface
        fun requestIgnoreBatteryOptimizations() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    runOnUiThread { startActivity(intent) }
                }
            }
        }
    }
}
