package com.fbda.blooddonate

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
            if (prefs.getBoolean("bg_service_enabled", true)) {
                ForegroundKeepAliveService.start(context)
            }
        }
    }
}
