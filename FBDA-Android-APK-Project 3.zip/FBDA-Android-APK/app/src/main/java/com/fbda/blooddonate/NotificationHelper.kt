package com.fbda.blooddonate

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object NotificationHelper {
    const val CHANNEL_URGENT = "fbda_urgent_alerts"
    const val CHANNEL_NOTICES = "fbda_notices"
    const val CHANNEL_BACKGROUND = "fbda_background_service"
    const val FOREGROUND_NOTIFICATION_ID = 1001

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val urgentChannel = NotificationChannel(
                CHANNEL_URGENT,
                context.getString(R.string.channel_urgent_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_urgent_desc)
                enableVibration(true)
                enableLights(true)
            }

            val noticeChannel = NotificationChannel(
                CHANNEL_NOTICES,
                context.getString(R.string.channel_notices_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.channel_notices_desc)
            }

            val bgChannel = NotificationChannel(
                CHANNEL_BACKGROUND,
                context.getString(R.string.channel_bg_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.channel_bg_desc)
                setShowBadge(false)
            }

            nm.createNotificationChannel(urgentChannel)
            nm.createNotificationChannel(noticeChannel)
            nm.createNotificationChannel(bgChannel)
        }
    }

    fun showAlertNotification(
        context: Context,
        title: String,
        body: String,
        deepLink: String = "#home",
        actionLabel: String? = null,
        phoneNumber: String? = null,
        channelId: String = CHANNEL_URGENT
    ) {
        createChannels(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val notifId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("deep_link", deepLink)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            deepLink.hashCode() + notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val largeIcon = BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(largeIcon)
            .setContentTitle(title.ifBlank { context.getString(R.string.app_name) })
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(
                if (channelId == CHANNEL_URGENT) NotificationCompat.PRIORITY_HIGH
                else NotificationCompat.PRIORITY_DEFAULT
            )
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        // Primary deep-link action button
        val primaryLabel = actionLabel?.takeIf { it.isNotBlank() } ?: when {
            deepLink.contains("blood") -> "View Blood Request"
            deepLink.contains("notice") -> "Read Notice"
            deepLink.contains("ambulance") -> "View Ambulance"
            else -> "Open App"
        }
        builder.addAction(R.drawable.ic_notification, primaryLabel, pendingIntent)

        // Optional direct Call Now action if phone number provided in push payload
        val cleanPhone = phoneNumber?.replace(Regex("[^+\\d]"), "") ?: ""
        if (cleanPhone.isNotBlank()) {
            val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
            val callPending = PendingIntent.getActivity(
                context,
                notifId + 1,
                callIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_call, "Call Now", callPending)
        } else {
            val dismissIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_DISMISS
                putExtra(NotificationActionReceiver.EXTRA_NOTIF_ID, notifId)
            }
            val dismissPending = PendingIntent.getBroadcast(
                context,
                notifId + 2,
                dismissIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, "Dismiss", dismissPending)
        }

        NotificationManagerCompat.from(context).notify(notifId, builder.build())
    }
}
