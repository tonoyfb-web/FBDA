package com.fbda.blooddonate

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ForegroundKeepAliveService : Service() {

    private var scheduler: ScheduledExecutorService? = null
    private var mediaPlayer: MediaPlayer? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var isPlayingAudio: Boolean = false

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannels(this)
        startAsForeground("Running in background for urgent blood alerts & audio")
        startBackgroundPoller()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_TONE -> {
                playAlertTone()
            }
            ACTION_PLAY_AUDIO_URL -> {
                val url = intent.getStringExtra(EXTRA_AUDIO_URL) ?: ""
                if (url.isNotBlank()) playAudioFromUrl(url)
            }
            ACTION_STOP_AUDIO -> {
                stopPlayback()
            }
            else -> {
                startAsForeground("Running in background for urgent blood alerts & audio")
            }
        }
        return START_STICKY
    }

    private fun startAsForeground(statusText: String) {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopServiceIntent = Intent(this, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_STOP_SERVICE
        }
        val stopServicePending = PendingIntent.getBroadcast(
            this,
            201,
            stopServiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val largeIcon = BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher)

        val builder = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_BACKGROUND)
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(largeIcon)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(statusText)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPending)
            .addAction(0, "Open App", openPending)

        if (isPlayingAudio) {
            val stopAudioIntent = Intent(this, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_STOP_AUDIO
            }
            val stopAudioPending = PendingIntent.getBroadcast(
                this,
                202,
                stopAudioIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, "Stop Audio", stopAudioPending)
        } else {
            builder.addAction(0, "Pause Service", stopServicePending)
        }

        val notification = builder.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            startForeground(NotificationHelper.FOREGROUND_NOTIFICATION_ID, notification, serviceType)
        } else {
            startForeground(NotificationHelper.FOREGROUND_NOTIFICATION_ID, notification)
        }
    }

    private fun requestAudioFocus(): Boolean {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { change ->
                    if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        stopPlayback()
                    }
                }
                .build()
            audioFocusRequest = req
            return audioManager.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        @Suppress("DEPRECATION")
        return audioManager.requestAudioFocus(
            null,
            AudioManager.STREAM_MUSIC,
            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun playAlertTone() {
        stopPlayback(updateNotification = false)
        if (!requestAudioFocus()) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@ForegroundKeepAliveService, uri)
                setOnCompletionListener { stopPlayback(updateNotification = true) }
                prepare()
                start()
            }
            isPlayingAudio = true
            startAsForeground("Playing alert audio in background")
        } catch (_: Exception) {
            stopPlayback(updateNotification = true)
        }
    }

    private fun playAudioFromUrl(url: String) {
        stopPlayback(updateNotification = false)
        if (!requestAudioFocus()) return
        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener {
                    it.start()
                    isPlayingAudio = true
                    startAsForeground("Playing background audio")
                }
                setOnCompletionListener { stopPlayback(updateNotification = true) }
                setOnErrorListener { _, _, _ ->
                    stopPlayback(updateNotification = true)
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            stopPlayback(updateNotification = true)
        }
    }

    private fun stopPlayback(updateNotification: Boolean = true) {
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {}
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        isPlayingAudio = false

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        }
        if (updateNotification) {
            startAsForeground("Running in background for urgent blood alerts & audio")
        }
    }

    private fun startBackgroundPoller() {
        if (scheduler != null) return
        scheduler = Executors.newSingleThreadScheduledExecutor()
        scheduler?.scheduleAtFixedRate({
            if (isNetworkAvailable(this)) {
                syncLatestDataInBackground(this)
            }
        }, 20, 120, TimeUnit.SECONDS)
    }

    override fun onDestroy() {
        stopPlayback(updateNotification = false)
        scheduler?.shutdownNow()
        scheduler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val SUPABASE_URL = "https://msgsmxmdrmigjyrrccfg.supabase.co"
        private const val SUPABASE_ANON_KEY = "sb_publishable_h2n9_j7CppeVW4-y_yNl3Q_w9_hjla6"

        const val ACTION_PLAY_TONE = "com.fbda.blooddonate.PLAY_TONE"
        const val ACTION_PLAY_AUDIO_URL = "com.fbda.blooddonate.PLAY_AUDIO_URL"
        const val ACTION_STOP_AUDIO = "com.fbda.blooddonate.STOP_AUDIO"
        const val EXTRA_AUDIO_URL = "audio_url"

        fun start(context: Context) {
            val intent = Intent(context, ForegroundKeepAliveService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ForegroundKeepAliveService::class.java))
        }

        fun playTone(context: Context) {
            val intent = Intent(context, ForegroundKeepAliveService::class.java).apply {
                action = ACTION_PLAY_TONE
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun playAudioUrl(context: Context, url: String) {
            val intent = Intent(context, ForegroundKeepAliveService::class.java).apply {
                action = ACTION_PLAY_AUDIO_URL
                putExtra(EXTRA_AUDIO_URL, url)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopAudio(context: Context) {
            val intent = Intent(context, ForegroundKeepAliveService::class.java).apply {
                action = ACTION_STOP_AUDIO
            }
            context.startService(intent)
        }

        fun isNetworkAvailable(context: Context): Boolean {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }

        fun syncLatestDataInBackground(context: Context) {
            checkLatestNotices(context)
            checkLatestBloodRequests(context)
        }

        private fun checkLatestNotices(context: Context) {
            try {
                val endpoint = URL("$SUPABASE_URL/rest/v1/notices?select=id,title,content,created_at&order=created_at.desc&limit=1")
                val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("apikey", SUPABASE_ANON_KEY)
                    setRequestProperty("Authorization", "Bearer $SUPABASE_ANON_KEY")
                }

                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONArray(body)
                    if (arr.length() > 0) {
                        val latest = arr.getJSONObject(0)
                        val id = latest.optString("id", "")
                        val title = latest.optString("title", "New FBDA Notice")
                        val content = latest.optString("content", "")

                        val prefs = context.getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                        val lastSeenId = prefs.getString("last_notice_id", "") ?: ""
                        if (id.isNotBlank() && lastSeenId.isNotBlank() && id != lastSeenId) {
                            NotificationHelper.showAlertNotification(
                                context = context,
                                title = "📌 $title",
                                body = content.take(160),
                                deepLink = "#notice-board",
                                actionLabel = "Read Notice",
                                channelId = NotificationHelper.CHANNEL_NOTICES
                            )
                        }
                        if (id.isNotBlank()) {
                            prefs.edit().putString("last_notice_id", id).apply()
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
                // Transient network errors ignored
            }
        }

        private fun checkLatestBloodRequests(context: Context) {
            try {
                val endpoint = URL("$SUPABASE_URL/rest/v1/blood_requests?select=id,patient_name,blood_group,hospital,urgency,contact_number&status=eq.Pending&order=created_at.desc&limit=1")
                val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("apikey", SUPABASE_ANON_KEY)
                    setRequestProperty("Authorization", "Bearer $SUPABASE_ANON_KEY")
                }

                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONArray(body)
                    if (arr.length() > 0) {
                        val req = arr.getJSONObject(0)
                        val id = req.optString("id", "")
                        val patient = req.optString("patient_name", "Patient")
                        val group = req.optString("blood_group", "")
                        val hospital = req.optString("hospital", "")
                        val urgency = req.optString("urgency", "Urgent")
                        val phone = req.optString("contact_number", "")

                        val prefs = context.getSharedPreferences("fbda_prefs", Context.MODE_PRIVATE)
                        val lastBloodId = prefs.getString("last_blood_req_id", "") ?: ""
                        if (id.isNotBlank() && lastBloodId.isNotBlank() && id != lastBloodId) {
                            NotificationHelper.showAlertNotification(
                                context = context,
                                title = "🩸 $urgency Blood Request ($group)",
                                body = "$patient needs $group blood at $hospital",
                                deepLink = "#blood-request",
                                actionLabel = "Respond Now",
                                phoneNumber = phone,
                                channelId = NotificationHelper.CHANNEL_URGENT
                            )
                        }
                        if (id.isNotBlank()) {
                            prefs.edit().putString("last_blood_req_id", id).apply()
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
                // Transient network errors ignored
            }
        }
    }
}
