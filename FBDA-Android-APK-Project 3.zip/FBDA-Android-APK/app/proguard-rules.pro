-keepclassmembers class com.fbda.blooddonate.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
